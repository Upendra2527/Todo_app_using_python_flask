from flask import Flask,render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///todo.db"
db = SQLAlchemy(app)

class Todo(db.Model):
    sno = db.Column(db.Integer,primary_key=True)
    Title = db.Column(db.String(200),nullable=False)
    desc = db.Column(db.String(500),nullable=False)
    Time = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self)->str:
        return f"{self.sno} - {self.Title}"
    

@app.route("/",methods=['GET','POST'])

def hello():
    if request.method == 'POST':
        todo_title = request.form['title']
        todo_desc = request.form['desc']
        data = Todo(Title=todo_title , desc = todo_desc)
        db.session.add(data)
        db.session.commit()
    alltodo = Todo.query.all()
    data = Todo(Title="first todo",desc="This is first todo desc")
    db.session.add(data)
    db.session.commit()
    return render_template("index.html",alltodo=alltodo)

@app.route('/delete/<int:sno>')

def delete(sno):
    todo = Todo.query.filter_by(sno=sno).first()
    db.session.delete(todo)
    db.session.commit()
    return '''<!DOCTYPE html>
<html>
<head>
  <title>Data Deletion Message</title>
  <style>
    body {
      font-family: Arial, sans-serif;
    }

    .message-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .message {
      padding: 20px;
      border: 2px solid #4CAF50;
      border-radius: 8px;
      background-color: #E8F5E9;
      color: #4CAF50;
      font-size: 18px;
      font-weight: bold;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="message-container">
    <div class="message">Data Deleted Successfully!</div>
  </div>
</body>
</html>

            '''

if __name__ == "__main__":
    app.run(debug=True)